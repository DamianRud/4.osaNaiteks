﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace _5osa.kolletsionid_1_7
{
    internal class Funktsionid
    {
        public static void Nimed()
        {
            ArrayList nimed = new ArrayList();
            nimed.Add("Kati");
            nimed.Add("Mati");
            nimed.Add("Juku");

            if (nimed.Contains("Mati"))
                Console.WriteLine("Mati olemas");

            Console.WriteLine("Nimesid kokku: " + nimed.Count);

            nimed.Insert(1, "Sass");

            Console.WriteLine("Mati indeks: " + nimed.IndexOf("Mati"));
            Console.WriteLine("Mari индекс: " + nimed.IndexOf("Mari"));

            foreach (string nimi in nimed)
                Console.WriteLine(nimi);
        }

        public static void Marsruut()
        {
            Tuple<float, char> route = new Tuple<float, char>(2.5f, 'N');
            Console.WriteLine($"Vahemaa: {route.Item1}, Suund: {route.Item2}");
        }

        public static void ShowPeople()
        {
            List<Person> people = new List<Person>();
            people.Add(new Person() { Name = "Kadi" });
            people.Add(new Person() { Name = "Mirje" });

            Person Lisa = new Person() { Name = "Kadi" };
            foreach (Person p in people)
                Console.WriteLine(p.Name);

            people.Remove(Lisa);

            foreach (Person p in people)
                Console.WriteLine(p.Name);
        }

        public static void list_Remove()
        {
            List<string> people = new List<string>() { "Kadi", "Mirje" };

            foreach (string p in people)
                Console.WriteLine(p);

            people.Add("Lisa");
            people.Remove("Lisa");

            Console.WriteLine("pärast eemaldamine Lisa:");
            foreach (string p in people)
                Console.WriteLine(p);

            people.RemoveAt(0);
            people.Insert(0, "Anna");
            people.Insert(1, "Mari");

            people.Sort();

            Console.WriteLine("Tähestikuline järjestus:");
            foreach (string p in people)
                Console.WriteLine(p);

            people.Sort((a, b) => a.Length.CompareTo(b.Length));

            Console.WriteLine("Sorteerimine nime pikkuse järgi:");
            foreach (string p in people)
                Console.WriteLine(p);
        }

        public static void LinkedListDemo()
        {
            LinkedList<int> loetelu = new LinkedList<int>();
            loetelu.AddLast(5);
            loetelu.AddLast(3);
            loetelu.AddFirst(0);

            Console.WriteLine("esialgne nimekiri");
            foreach (int arv in loetelu)
                Console.WriteLine(arv);

            loetelu.RemoveFirst();
            loetelu.RemoveLast();
            loetelu.AddLast(555);
            loetelu.Remove(555);

            Console.WriteLine("pärast operatsionid:");
            foreach (int arv in loetelu)
                Console.WriteLine(arv);
        }

        public static void sõnastik()
        {
            Dictionary<int, string> riigid = new Dictionary<int, string>();
            riigid.Add(1, "Hiina");
            riigid.Add(2, "Eesti");
            riigid.Add(3, "Itaalia");

            foreach (var paar in riigid)
                Console.WriteLine($"{paar.Key} - {paar.Value}");

            string pealinn = riigid[2];
            riigid[2] = "Eestimaa";
            riigid.Remove(3);


            Dictionary<char, Person> inimesed = new Dictionary<char, Person>();
            inimesed.Add('k', new Person() { Name = "Kadi" });
            inimesed.Add('m', new Person() { Name = "Mait" });

            foreach (var entry in inimesed)
                Console.WriteLine($"{entry.Key} - {entry.Value.Name}");
        }
        public static void ArvudeStatistika()
        {

            {

                double[] numbrid = { 10.5, 20, 5.7, 30, 15.2 };


                double summa = 0;
                foreach (double n in numbrid)
                {
                    summa = summa + n;
                }


                double keskmine = summa / numbrid.Length;


                double max = numbrid[0];
                double min = numbrid[0];

                foreach (double n in numbrid)
                {
                    if (n > max)
                    {
                        max = n;
                    }

                    if (n < min)
                    {
                        min = n;
                    }
                }


                int rohkemKuiKeskmine = 0;
                foreach (double n in numbrid)
                {
                    if (n > keskmine)
                    {
                        rohkemKuiKeskmine++;
                    }
                }

                Console.WriteLine("--- Arvude Statistika (Vana viis) ---");

                Console.Write("Massiiv: ");
                foreach (double n in numbrid)
                {

                }

                Console.WriteLine($"Maksimaalne: {max}");
                Console.WriteLine($"Minimaalne: {min}");
                Console.WriteLine($"Summa: {summa}");
                Console.WriteLine($"Keskmine: {keskmine:F2}");
                Console.WriteLine($"Arve, mis on suuremad kui keskmine: {rohkemKuiKeskmine}");
                {

                }
            }
        }

        public static void LemmikloomadeProgramm()
        {

            List<Lemmikloom> loomad = new List<Lemmikloom>();


            Lemmikloom loom1 = new Lemmikloom();
            loom1.Nimi = "Murka";
            loom1.Liik = "kass";
            loom1.Vanus = 5;
            loomad.Add(loom1);


            loomad.Add(new Lemmikloom { Nimi = "Sharik", Liik = "koer", Vanus = 8 });
            loomad.Add(new Lemmikloom { Nimi = "Kiti", Liik = "kass", Vanus = 2 });


            Console.WriteLine("--- Meie kassid: ---");
            foreach (Lemmikloom l in loomad)
            {
                if (l.Liik == "kass")
                {
                    Console.WriteLine($"{l.Nimi}, vanus: {l.Vanus}");
                }
            }


            Lemmikloom vanim = loomad[0];
            foreach (Lemmikloom l in loomad)
            {
                if (l.Vanus > vanim.Vanus)
                {
                    vanim = l;
                }
            }

            Console.WriteLine($"Vanim loom on {vanim.Nimi}, ta on {vanim.Liik} ta on  {vanim.Vanus} aastat vana.");
        }
        public static void ValuutaKalkulaator()
        {

            List<Valuuta> valuutad = new List<Valuuta>();
            valuutad.Add(new Valuuta { Nimetus = "USD", Kurss = 0.92 });
            valuutad.Add(new Valuuta { Nimetus = "GBP", Kurss = 1.17 });
            valuutad.Add(new Valuuta { Nimetus = "JPY", Kurss = 0.006 });


            Console.Write("Sisesta summa: ");
            double summa = double.Parse(Console.ReadLine());

            Console.Write("Sisesta valuuta nimi (USD, GBP, JPY): ");
            string otsitav = Console.ReadLine().ToUpper();


            bool leitud = false;
            foreach (Valuuta v in valuutad)
            {
                if (v.Nimetus == otsitav)
                {
                    double tulemus = summa * v.Kurss;
                    Console.WriteLine($"{summa} {v.Nimetus} on {tulemus:F2} EUR");


                    double tagurpidi = summa / v.Kurss;
                    Console.WriteLine($"{summa} EUR on {tagurpidi:F2} {v.Nimetus}");

                    leitud = true;
                    break;
                }
            }

            if (!leitud)
            {
                Console.WriteLine("Sellist valuutat ei leitud!");
            }
        }

        public static void OpilasteProgramm()
        {
            List<Opilane> opilased = new List<Opilane>
    {
        new Opilane { Nimi = "Anna", Hinded = new List<int> { 5, 4, 5 } },
        new Opilane { Nimi = "Mark", Hinded = new List<int> { 3, 4, 3 } },
        new Opilane { Nimi = "Olga", Hinded = new List<int> { 5, 5, 4 } }
    };

            Console.WriteLine("Keskmised hinded:");

            double parim = 0;
            string parimNimi = "";

            foreach (var op in opilased)
            {
                int summa = 0;

                foreach (int hinne in op.Hinded)
                {
                    summa += hinne;
                }

                double keskmine = (double)summa / op.Hinded.Count;

                Console.WriteLine(op.Nimi + ": " + keskmine);

                if (keskmine > parim)
                {
                    parim = keskmine;
                    parimNimi = op.Nimi;
                }
            }

            Console.WriteLine("Parim õpilane:");
            Console.WriteLine(parimNimi + "" + parim + "");
        }
        public static void MaakonnadJaPealinnad()

        {
            Dictionary<string, string> maakonnad = new Dictionary<string, string>()
    {
        { "Harjumaa", "Tallinn" },
        { "Tartumaa", "Tartu" },
        { "Pärnumaa", "Pärnu" }
    };

            Console.WriteLine("1 - Leia pealinn maakonna järgi");
            Console.WriteLine("2 - Leia maakond pealinna järgi");
            Console.WriteLine("3 - Lisa uus");
            Console.WriteLine("4 - Mäng");
            Console.Write("Valik: ");

            string valik = Console.ReadLine();

            if (valik == "1")
            {
                Console.Write("Sisesta maakond: ");
                string mk = Console.ReadLine();

                if (maakonnad.ContainsKey(mk))
                {
                    Console.WriteLine("Pealinn: " + maakonnad[mk]);
                }
                else
                {
                    Console.WriteLine("Ei leitud!");
                }
            }


            else if (valik == "2")
            {
                Console.Write("Sisesta pealinn: ");
                string linn = Console.ReadLine();

                bool leitud = false;

                foreach (var paar in maakonnad)
                {
                    if (paar.Value.ToLower() == linn.ToLower())
                    {
                        Console.WriteLine("Maakond: " + paar.Key);
                        leitud = true;
                    }
                }

                if (!leitud)
                {
                    Console.WriteLine("Ei leitud!");
                }
            }


            else if (valik == "3")
            {
                Console.Write("Sisesta maakond: ");
                string mk = Console.ReadLine();

                Console.Write("Sisesta pealinn: ");
                string linn = Console.ReadLine();

                maakonnad[mk] = linn;

                Console.WriteLine("Lisatud!");
            }


            else if (valik == "4")
            {
                int oige = 0;
                int kokku = 0;

                Random rnd = new Random();

                foreach (var paar in maakonnad)
                {
                    Console.WriteLine("\nMis on maakonna " + paar.Key + " pealinn?");
                    string vastus = Console.ReadLine();

                    if (vastus.ToLower() == paar.Value.ToLower())
                    {
                        Console.WriteLine("Õige!");
                        oige++;
                    }
                    else
                    {
                        Console.WriteLine("Vale! Õige: " + paar.Value);
                    }

                    kokku++;
                }

                double protsent = (double)oige / kokku * 100;
                Console.WriteLine("\nTulemus: " + protsent + "%");
            }
        }



        class Toode
        {
            public string Nimi { get; set; }
            public double Kalorid100g { get; set; }

            public Toode(string nimi, double kalorid)
            {
                Nimi = nimi;
                Kalorid100g = kalorid;
            }
        }

        class Inimene
        {
            public string Nimi;
            public int Vanus;
            public string Sugu; // "M" või "F"
            public double Pikkus; // cm
            public double Kaal;   // kg
            public double Aktiivsus; // koefitsient: 1.2 – 1.9

            public Inimene(string nimi, int vanus, string sugu, double pikkus, double kaal, double aktiivsus)
            {
                Nimi = nimi;
                Vanus = vanus;
                Sugu = sugu;
                Pikkus = pikkus;
                Kaal = kaal;
                Aktiivsus = aktiivsus;
            }
            public double PäevaneKalorivajadus()
            {
                // Harris-Benedict valem
                double bmr = 0;
                if (Sugu.ToUpper() == "M")
                {
                    bmr = 66.5 + (13.75 * Kaal) + (5.003 * Pikkus) - (6.775 * Vanus);
                }
                else if (Sugu.ToUpper() == "F")
                {
                    bmr = 655 + (9.563 * Kaal) + (1.850 * Pikkus) - (4.676 * Vanus);
                }
                return bmr * Aktiivsus;
            }
        }
        public static void KaloriteKalkulaator()
            {
                // 1. Toidud (можно добавить новые продукты вручную)
                List<Toode> toidud = new List<Toode>
    {
        new Toode("Leib", 265),
        new Toode("Munad", 155),
        new Toode("Kana", 165),
        new Toode("Õun", 52),
        new Toode("Juust", 350)
    };

                // 2. Ввод данных пользователя
                Console.Write("Sisesta nimi: ");
                string nimi = Console.ReadLine();

                Console.Write("Vanus: ");
                int vanus = int.Parse(Console.ReadLine());

                Console.Write("Sugu (M/F): ");
                string sugu = Console.ReadLine();

                Console.Write("Pikkus (cm): ");
                double pikkus = double.Parse(Console.ReadLine());

                Console.Write("Kaal (kg): ");
                double kaal = double.Parse(Console.ReadLine());

                Console.Write("Aktiivsustase (1.2 – 1.9): ");
                double aktiivsus = double.Parse(Console.ReadLine());

                Inimene kasutaja = new Inimene(nimi, vanus, sugu, pikkus, kaal, aktiivsus);

                double kalorid = kasutaja.PäevaneKalorivajadus();
                Console.WriteLine($"\n{nimi}, sinu päevane kalorivajadus on: {kalorid:F0} kcal\n");

                // 3. Расчет необходимого количества каждого продукта
                Console.WriteLine("Kogus toidust 1 päeva kalorite katmiseks:");

                foreach (var toode in toidud)
                {
                    double grammid = (kalorid / toode.Kalorid100g) * 100;
                    Console.WriteLine($"{toode.Nimi}: {grammid:F0} g");
                }
            }

        }













        public class Valuuta
        {
            public string Nimetus { get; set; }
            public double Kurss { get; set; }
        }

        public class Lemmikloom
        {
            public string Nimi { get; set; }
            public string Liik { get; set; }
            public int Vanus { get; set; }
        }



        class Person
        {
            public string Name { get; set; }
        }


        class Opilane
        {
            public string Nimi;
            public List<int> Hinded;
        }
    }


